﻿var f1 = new Fumante((int)Ingredientes.Fumo, "Luiz");
var f2 = new Fumante((int)Ingredientes.Papel, "Yuri");
var f3 = new Fumante((int)Ingredientes.Fosforo, "Carlos");
var t1 = new Thread(f1.simular);
var t2 = new Thread(f2.simular);
var t3 = new Thread(f3.simular);
t1.Start();
t2.Start();
t3.Start();
var fornecedor = new Fornecedor();


fornecedor.gerarTrava(f1);
fornecedor.gerarTrava(f2);
fornecedor.gerarTrava(f3);

fornecedor.simular();
