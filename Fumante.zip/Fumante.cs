using System.Threading;
using System.Collections.Generic;
enum Ingredientes 
{
	Fumo = 0b001,
	Papel = 0b010,
	Fosforo = 0b100,
}


class Fornecedor
{
	public Dictionary<Fumante, Mutex> fumantes = new Dictionary<Fumante, Mutex>();	

	public void gerarTrava(Fumante f)
	{
		var m = new Mutex();
		m.WaitOne();
		fumantes.Add(f, m); 
		f.trava = m;
	}

	public void simular()
	{
		while(true) {
			int ingredientesGerados = 0;
			var x = new List<int>(){
				(int)Ingredientes.Fumo,
				(int)Ingredientes.Papel,
				(int)Ingredientes.Fosforo,
			};
			for (int i = 0; i < 2; i++)
			{
				var indice = new Random().Next(x.Count());
				ingredientesGerados |= x[indice];
				x.RemoveAt(indice);

			}

			Mutex trava = null;

			foreach(KeyValuePair<Fumante, Mutex> entrada in fumantes)
			{
				if ((entrada.Key.ingredienteInicial | ingredientesGerados) == 0b111) 
				{
					trava = entrada.Value;
					entrada.Key.ingredientesAtuais  = 0b111;
					break;
				}
			}

			trava.ReleaseMutex();
			Thread.Sleep(100);
			trava.WaitOne();

		}
		
	}
}


class Fumante 
{
	public string nome;
	public int ingredientesAtuais;
	public int ingredienteInicial;
	public Mutex? trava = null;

	public Fumante(int ingredientes, string nome)
	{
		this.ingredienteInicial = ingredientes;
		this.ingredientesAtuais = ingredientes;
		this.nome = nome;
	}


	public void simular(Object? nada)
	{
		while(true) 
		{
			if (trava != null)
			{
				trava.WaitOne();
				Console.WriteLine($"{nome} está fumando");
				Thread.Sleep(new Random().Next(3500));
				Console.WriteLine($"{nome} terminou de fumar");
				trava.ReleaseMutex();
                Thread.Sleep(100);
            }
        }
	}
}
